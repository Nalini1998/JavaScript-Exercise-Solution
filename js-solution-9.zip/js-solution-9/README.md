# JS Solution 9

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini-Vo-the-solid/pen/VwRKKbN](https://codepen.io/Nalini-Vo-the-solid/pen/VwRKKbN).

