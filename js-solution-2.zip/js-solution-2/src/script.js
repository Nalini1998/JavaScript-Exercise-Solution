const myFunc = () => {window.print()};
// document.getElementById("demo1").innerHTML = window.print();
//document.getElementById("demo2").innerHTML = `Current time is : ${hour} ${pre} : ${min} : ${sec}`;