# JS Solution 3

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini-Vo-the-solid/pen/MWxjaqj](https://codepen.io/Nalini-Vo-the-solid/pen/MWxjaqj).

