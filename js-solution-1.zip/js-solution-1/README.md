# JS Solution 1

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini-Vo-the-solid/pen/mdordja](https://codepen.io/Nalini-Vo-the-solid/pen/mdordja).

