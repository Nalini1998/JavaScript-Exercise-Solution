# JS Solution 7

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini-Vo-the-solid/pen/ExMgypX](https://codepen.io/Nalini-Vo-the-solid/pen/ExMgypX).

