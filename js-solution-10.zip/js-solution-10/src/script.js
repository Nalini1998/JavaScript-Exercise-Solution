const division = () => {
  const num1 = document.getElementById('num1').value;
  const num2 = document.getElementById('num2').value;
  document.getElementById('output').innerHTML = num1/num2;
}

const multiplication = () => {
  const num1 = document.getElementById('num1').value;
  const num2 = document.getElementById('num2').value;
  document.getElementById('output').innerHTML = num1*num2;
}