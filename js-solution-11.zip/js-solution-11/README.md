# JS Solution 11

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini-Vo-the-solid/pen/GRejELe](https://codepen.io/Nalini-Vo-the-solid/pen/GRejELe).

