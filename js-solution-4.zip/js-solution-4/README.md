# JS Solution 4

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini-Vo-the-solid/pen/QWoKyMd](https://codepen.io/Nalini-Vo-the-solid/pen/QWoKyMd).

